package com.trt.nativeapp;

import java.util.*;
import android.content.Context;

public final class TimeWindow {
    public static long[] get(Context c) {
        android.content.SharedPreferences p = c.getSharedPreferences("trt", 0);
        int w = p.getInt("wh", 7) * 60 + p.getInt("wm", 0);
        int b = p.getInt("bh", 22) * 60 + p.getInt("bm", 30);

        Calendar now = Calendar.getInstance();
        Calendar st = (Calendar) now.clone();
        Calendar en = (Calendar) now.clone();

        st.set(Calendar.HOUR_OF_DAY, w / 60);
        st.set(Calendar.MINUTE, w % 60);
        st.set(Calendar.SECOND, 0);
        st.set(Calendar.MILLISECOND, 0);

        en.set(Calendar.HOUR_OF_DAY, b / 60);
        en.set(Calendar.MINUTE, b % 60);
        en.set(Calendar.SECOND, 0);
        en.set(Calendar.MILLISECOND, 0);

        // If the deadline is numerically earlier than the wake time,
        // the usable window crosses midnight.
        if (!en.after(st)) en.add(Calendar.DATE, 1);

        // IMPORTANT: keep today's window. After the deadline we need the
        // elapsed time since today's deadline, not tomorrow's countdown.
        return new long[]{st.getTimeInMillis(), en.getTimeInMillis()};
    }
}
