package com.trt.nativeapp;
import android.app.PendingIntent; import android.appwidget.*; import android.content.*; import android.os.*; import android.widget.*; import java.text.*; import java.util.*;
public class TRTWidget extends AppWidgetProvider {
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)update(c,m,id);}
 static void update(Context c,AppWidgetManager m,int id){
  long[] x=TimeWindow.get(c); long start=x[0], end=x[1], now=System.currentTimeMillis();
  RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget);
  if(now < start){
   v.setChronometer(R.id.widget_timer,SystemClock.elapsedRealtime() + (end-start),"%s",true);
   v.setChronometerCountDown(R.id.widget_timer,true);
  } else if(now <= end){
   v.setChronometer(R.id.widget_timer,SystemClock.elapsedRealtime() + (end-now),"%s",true);
   v.setChronometerCountDown(R.id.widget_timer,true);
  } else {
   // After the deadline, count down to the next day's start time.
   long nextStart=start + 24L*60L*60L*1000L;
   v.setChronometer(R.id.widget_timer,SystemClock.elapsedRealtime() + (nextStart-now),"%s",true);
   v.setChronometerCountDown(R.id.widget_timer,true);
  }
  v.setTextViewText(R.id.widget_end,"Deadline "+new SimpleDateFormat("hh:mm a",Locale.US).format(new Date(end)));
  Intent i=new Intent(c,MainActivity.class);
  PendingIntent pi=PendingIntent.getActivity(c,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  v.setOnClickPendingIntent(R.id.widget_timer,pi);
  m.updateAppWidget(id,v);
 }
 public static void refresh(Context c){
  AppWidgetManager m=AppWidgetManager.getInstance(c); ComponentName n=new ComponentName(c,TRTWidget.class);
  for(int id:m.getAppWidgetIds(n)) update(c,m,id);
 }
}
