package com.trt.nativeapp;
import android.app.*; import android.content.*; import android.os.*;
public class TRTService extends Service {
 static final int ID=77, NOTIF=77, CH=1;
 @Override public void onCreate(){super.onCreate();
  if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel("trt","TRT",NotificationManager.IMPORTANCE_LOW);
   ch.setDescription("Time Remaining Today"); getSystemService(NotificationManager.class).createNotificationChannel(ch);}
 }
 @Override public int onStartCommand(Intent i,int flags,int id){post();return START_STICKY;}
 void post(){
  long end=TimeWindow.get(this)[1];
  PendingIntent pi=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  Notification.Builder b=new Notification.Builder(this,"trt")
   .setSmallIcon(R.drawable.ic_launcher).setContentTitle("TRT — Time Remaining Today")
   .setWhen(end).setUsesChronometer(true).setChronometerCountDown(true).setShowWhen(true)
   .setOngoing(true).setOnlyAlertOnce(true).setVisibility(Notification.VISIBILITY_PUBLIC).setContentIntent(pi);
  startForeground(ID,b.build());
 }
 @Override public IBinder onBind(Intent i){return null;}
}