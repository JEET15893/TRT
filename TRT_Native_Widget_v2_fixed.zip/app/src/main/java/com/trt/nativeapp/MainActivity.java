package com.trt.nativeapp;
import android.app.*; import android.os.*; import android.content.*; import android.content.pm.PackageManager; import android.widget.*;
import java.text.*; import java.util.*;
public class MainActivity extends Activity {
 Chronometer timer; TextView endText; TimePicker wake,bed; android.content.SharedPreferences p;
 @Override public void onCreate(Bundle b){
  super.onCreate(b); setContentView(R.layout.activity_main); p=getSharedPreferences("trt",0);
  timer=findViewById(R.id.timer); endText=findViewById(R.id.endText); wake=findViewById(R.id.wake); bed=findViewById(R.id.bed);
  wake.setHour(p.getInt("wh",7)); wake.setMinute(p.getInt("wm",0)); bed.setHour(p.getInt("bh",22)); bed.setMinute(p.getInt("bm",30));
  findViewById(R.id.save).setOnClickListener(v->{save(); refresh(); TRTWidget.refresh(this); startForegroundService(new Intent(this,TRTService.class));});
  refresh();
  if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)
   requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},5);
  startForegroundService(new Intent(this,TRTService.class));
 }
 void save(){p.edit().putInt("wh",wake.getHour()).putInt("wm",wake.getMinute()).putInt("bh",bed.getHour()).putInt("bm",bed.getMinute()).apply();}
 void refresh(){long[] x=TimeWindow.get(this); long remain=Math.max(0,x[1]-System.currentTimeMillis());
  timer.setBase(SystemClock.elapsedRealtime()+remain); timer.setCountDown(true); timer.setFormat("%s"); timer.start();
  endText.setText("Deadline "+new SimpleDateFormat("hh:mm a",Locale.US).format(new Date(x[1])));
 }
}