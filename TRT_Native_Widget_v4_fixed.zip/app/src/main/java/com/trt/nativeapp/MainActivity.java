package com.trt.nativeapp;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    Chronometer timer;
    TextView percentText;
    ProgressBar progress;
    View displayPanel, settingsPanel;
    TimePicker wake, bed;
    SharedPreferences p;
    Handler handler = new Handler(Looper.getMainLooper());

    final Runnable updater = new Runnable() {
        @Override public void run() {
            if (displayPanel.getVisibility() == View.VISIBLE) updateDisplay();
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        p = getSharedPreferences("trt", 0);
        timer = findViewById(R.id.timer);
        percentText = findViewById(R.id.percentText);
        progress = findViewById(R.id.progress);
        displayPanel = findViewById(R.id.displayPanel);
        settingsPanel = findViewById(R.id.settingsPanel);
        wake = findViewById(R.id.wake);
        bed = findViewById(R.id.bed);

        wake.setHour(p.getInt("wh", 7));
        wake.setMinute(p.getInt("wm", 0));
        bed.setHour(p.getInt("bh", 22));
        bed.setMinute(p.getInt("bm", 30));

        findViewById(R.id.save).setOnClickListener(v -> {
            save();
            showDisplay();
            TRTWidget.refresh(this);
            startForegroundService(new Intent(this, TRTService.class));
        });

        findViewById(R.id.setDay).setOnClickListener(v -> showSettings());

        boolean configured = p.getBoolean("configured", false);
        if (configured) showDisplay();
        else showSettings();

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 5);
        }

        startForegroundService(new Intent(this, TRTService.class));
        handler.post(updater);
    }

    void save() {
        p.edit()
            .putInt("wh", wake.getHour())
            .putInt("wm", wake.getMinute())
            .putInt("bh", bed.getHour())
            .putInt("bm", bed.getMinute())
            .putBoolean("configured", true)
            .apply();
    }

    void showDisplay() {
        settingsPanel.setVisibility(View.GONE);
        displayPanel.setVisibility(View.VISIBLE);
        updateDisplay();
    }

    void showSettings() {
        displayPanel.setVisibility(View.GONE);
        settingsPanel.setVisibility(View.VISIBLE);
    }

    void updateDisplay() {
        long[] x = TimeWindow.get(this);
        long start = x[0], end = x[1], now = System.currentTimeMillis();
        long total = Math.max(1, end - start);
        long remain = Math.max(0, end - now);

        // Before the wake time, show the full usable day as remaining.
        if (now < start) remain = total;

        long bounded = Math.min(remain, total);
        int pct = (int)Math.round((bounded * 100.0) / total);
        pct = Math.max(0, Math.min(100, pct));

        timer.setBase(SystemClock.elapsedRealtime() + bounded);
        timer.setCountDown(true);
        timer.setFormat("%s");
        timer.start();

        percentText.setText(pct + "% of your usable day remains");
        progress.setProgress(pct);
    }

    @Override protected void onResume() {
        super.onResume();
        if (displayPanel != null && displayPanel.getVisibility() == View.VISIBLE) updateDisplay();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(updater);
        super.onDestroy();
    }
}
