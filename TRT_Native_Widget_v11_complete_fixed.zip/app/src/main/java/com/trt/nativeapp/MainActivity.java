package com.trt.nativeapp;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.widget.Chronometer;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

public class MainActivity extends Activity {
    private Chronometer timer;
    private TextView percentText;
    private View progressTrack, progressFill;
    private View displayPanel, settingsPanel;
    private TimePicker wake, bed;
    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable updater = new Runnable() {
        @Override public void run() {
            if (displayPanel != null && displayPanel.getVisibility() == View.VISIBLE) {
                updateDisplay();
            }
            handler.postDelayed(this, 1000L);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("trt", MODE_PRIVATE);
        timer = (Chronometer) findViewById(R.id.timer);
        percentText = (TextView) findViewById(R.id.percentText);
        progressTrack = findViewById(R.id.progressTrack);
        progressFill = findViewById(R.id.progressFill);
        displayPanel = findViewById(R.id.displayPanel);
        settingsPanel = findViewById(R.id.settingsPanel);
        wake = (TimePicker) findViewById(R.id.wake);
        bed = (TimePicker) findViewById(R.id.bed);

        wake.setHour(prefs.getInt("wh", 7));
        wake.setMinute(prefs.getInt("wm", 0));
        bed.setHour(prefs.getInt("bh", 22));
        bed.setMinute(prefs.getInt("bm", 20));

        findViewById(R.id.save).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (wake.getHour() == bed.getHour() && wake.getMinute() == bed.getMinute()) {
                    Toast.makeText(MainActivity.this,
                            "Wake and deadline cannot be the same time.",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                save();
                showDisplay();
                TRTWidget.refresh(MainActivity.this);
                startForegroundService(new Intent(MainActivity.this, TRTService.class));
            }
        });

        findViewById(R.id.setDay).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                showSettings();
            }
        });

        if (prefs.getBoolean("configured", false)) {
            showDisplay();
        } else {
            showSettings();
        }

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 5);
        }

        startForegroundService(new Intent(this, TRTService.class));
        handler.post(updater);
    }

    private void save() {
        prefs.edit()
                .putInt("wh", wake.getHour())
                .putInt("wm", wake.getMinute())
                .putInt("bh", bed.getHour())
                .putInt("bm", bed.getMinute())
                .putBoolean("configured", true)
                .apply();
    }

    private void showDisplay() {
        settingsPanel.setVisibility(View.GONE);
        displayPanel.setVisibility(View.VISIBLE);
        updateDisplay();
    }

    private void showSettings() {
        displayPanel.setVisibility(View.GONE);
        settingsPanel.setVisibility(View.VISIBLE);
    }

    private void updateDisplay() {
        long[] window = TimeWindow.get(this);
        long start = window[0];
        long end = window[1];
        long now = System.currentTimeMillis();
        long total = Math.max(1L, end - start);
        long remaining = Math.max(0L, end - now);
        long bounded = Math.max(0L, Math.min(remaining, total));

        int calculatedPct = (int) Math.round((bounded * 100.0) / total);
        final int pct = Math.max(0, Math.min(100, calculatedPct));

        timer.setBase(SystemClock.elapsedRealtime() + bounded);
        timer.setCountDown(true);
        timer.setFormat("%s");
        timer.start();

        percentText.setText(pct + "%");
        updateProgressFill(pct);
    }

    private void updateProgressFill(final int pct) {
        progressTrack.post(new Runnable() {
            @Override public void run() {
                int width = progressTrack.getWidth();
                int fillWidth = Math.round(width * (pct / 100.0f));
                android.view.ViewGroup.LayoutParams lp = progressFill.getLayoutParams();
                lp.width = fillWidth;
                progressFill.setLayoutParams(lp);
            }
        });
    }

    @Override protected void onResume() {
        super.onResume();
        if (displayPanel != null && displayPanel.getVisibility() == View.VISIBLE) {
            updateDisplay();
        }
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(updater);
        super.onDestroy();
    }
}
