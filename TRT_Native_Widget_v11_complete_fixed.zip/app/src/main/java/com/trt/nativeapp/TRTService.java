package com.trt.nativeapp;

import android.app.*;
import android.content.*;
import android.os.*;

public class TRTService extends Service {
    static final int ID=77, CH=1;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            post();
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(){
        super.onCreate();
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel("trt","TRT",NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Time Remaining");
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    @Override public int onStartCommand(Intent i,int flags,int id){
        handler.removeCallbacks(ticker);
        ticker.run();
        return START_STICKY;
    }

    void post(){
        long[] x=TimeWindow.get(this);
        long end=x[1], now=System.currentTimeMillis();
        long remaining=Math.max(0,end-now);
        PendingIntent pi=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b=new Notification.Builder(this,"trt")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("TRT — Time Remaining")
            .setWhen(System.currentTimeMillis()+remaining)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setShowWhen(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setContentIntent(pi);
        startForeground(ID,b.build());
        TRTWidget.refresh(this);
    }

    @Override public void onDestroy(){
        handler.removeCallbacks(ticker);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i){return null;}
}
