package com.trt.nativeapp;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.widget.RemoteViews;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TRTWidget extends AppWidgetProvider {
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) update(context, manager, id);
    }

    static void update(Context context, AppWidgetManager manager, int id) {
        long[] window = TimeWindow.get(context);
        long start = window[0];
        long end = window[1];
        long now = System.currentTimeMillis();
        long total = Math.max(1L, end - start);
        long remaining = Math.max(0L, end - now);
        int pct = Math.max(0, Math.min(100,
                (int) Math.round(Math.min(remaining, total) * 100.0 / total)));

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget);
        views.setChronometer(R.id.widget_timer,
                SystemClock.elapsedRealtime() + remaining, "%s", true);
        views.setChronometerCountDown(R.id.widget_timer, true);
        views.setProgressBar(R.id.widget_progress, 100, pct, false);
        views.setTextViewText(R.id.widget_percent, pct + "%");
        views.setTextViewText(R.id.widget_end,
                "Deadline " + new SimpleDateFormat("hh:mm a", Locale.US)
                        .format(new Date(end)));

        Intent intent = new Intent(context, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        views.setOnClickPendingIntent(R.id.widget_root, pendingIntent);

        manager.updateAppWidget(id, views);
    }

    public static void refresh(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName name = new ComponentName(context, TRTWidget.class);
        for (int id : manager.getAppWidgetIds(name)) update(context, manager, id);
    }
}
