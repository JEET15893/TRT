package com.trt.nativeapp;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Calendar;

public final class TimeWindow {
    private TimeWindow() {}

    /** Returns {start,end} for the currently active wake-to-deadline or deadline-to-wake window. */
    public static long[] get(Context context) {
        SharedPreferences p = context.getSharedPreferences("trt", Context.MODE_PRIVATE);
        int wakeMinutes = p.getInt("wh", 7) * 60 + p.getInt("wm", 0);
        int deadlineMinutes = p.getInt("bh", 22) * 60 + p.getInt("bm", 20);

        Calendar now = Calendar.getInstance();
        Calendar wakeToday = (Calendar) now.clone();
        Calendar deadlineToday = (Calendar) now.clone();
        setTime(wakeToday, wakeMinutes);
        setTime(deadlineToday, deadlineMinutes);

        // If the deadline clock time is earlier than wake, the day window crosses midnight.
        if (!deadlineToday.after(wakeToday)) {
            deadlineToday.add(Calendar.DATE, 1);
        }

        long nowMs = now.getTimeInMillis();
        long wakeMs = wakeToday.getTimeInMillis();
        long deadlineMs = deadlineToday.getTimeInMillis();

        if (nowMs >= wakeMs && nowMs < deadlineMs) {
            return new long[]{wakeMs, deadlineMs};
        }

        if (nowMs >= deadlineMs) {
            Calendar nextWake = (Calendar) wakeToday.clone();
            nextWake.add(Calendar.DATE, 1);
            return new long[]{deadlineMs, nextWake.getTimeInMillis()};
        }

        Calendar previousDeadline = (Calendar) deadlineToday.clone();
        previousDeadline.add(Calendar.DATE, -1);
        return new long[]{previousDeadline.getTimeInMillis(), wakeMs};
    }

    private static void setTime(Calendar c, int minutes) {
        c.set(Calendar.HOUR_OF_DAY, minutes / 60);
        c.set(Calendar.MINUTE, minutes % 60);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
    }
}
