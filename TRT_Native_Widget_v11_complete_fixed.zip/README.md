# TRT Native Widget

A native Android countdown for a configurable wake time and deadline.

- Main screen: live countdown, remaining percentage, green progress bar.
- Home-screen widget: live countdown, percentage, green progress bar, deadline.
- Notification: persistent countdown while the foreground service is active.
- Day window: wake -> deadline.
- Night window: deadline -> next wake.

## Build

Run the GitHub Actions workflow **Build TRT APK** manually. It produces `app-debug.apk` as a workflow artifact.

The project is intentionally self-contained; the workflow does not unzip another project or depend on another repository file.
