package com.trt.nativeapp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/** A slim, rounded progress line matching the TRT dark UI. */
public class ProgressLineView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float percent = 100f;
    private final float density;

    public ProgressLineView(Context context, AttributeSet attrs) {
        super(context, attrs);
        density = getResources().getDisplayMetrics().density;
        paint.setStyle(Paint.Style.FILL);
    }

    public void setProgress(int value) {
        percent = Math.max(0f, Math.min(100f, value));
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        float radius = h / 2f;

        // Dark track.
        paint.setColor(0xFF303030);
        canvas.drawRoundRect(0, 0, w, h, radius, radius, paint);

        // Spotify-style green fill. Rounded at both ends.
        float filled = w * (percent / 100f);
        if (filled > 0f) {
            paint.setColor(0xFF1DB954);
            float fillRadius = Math.min(radius, filled / 2f);
            canvas.drawRoundRect(0, 0, filled, h, fillRadius, fillRadius, paint);
        }
    }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int desiredHeight = (int) (14 * density + 0.5f);
        int width = MeasureSpec.getSize(widthMeasureSpec);
        setMeasuredDimension(width, desiredHeight);
    }
}
