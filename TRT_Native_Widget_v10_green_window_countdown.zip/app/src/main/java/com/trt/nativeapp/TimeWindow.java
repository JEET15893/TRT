package com.trt.nativeapp;

import java.util.*;
import android.content.Context;

public final class TimeWindow {
    /**
     * Returns the currently active countdown window.
     * Day window: wake -> deadline.
     * Night window: deadline -> next wake.
     */
    public static long[] get(Context c) {
        android.content.SharedPreferences p = c.getSharedPreferences("trt", 0);
        int w = p.getInt("wh", 7) * 60 + p.getInt("wm", 0);
        int b = p.getInt("bh", 22) * 60 + p.getInt("bm", 20);

        Calendar now = Calendar.getInstance();
        Calendar wakeToday = (Calendar) now.clone();
        Calendar bedToday = (Calendar) now.clone();
        wakeToday.set(Calendar.HOUR_OF_DAY, w / 60);
        wakeToday.set(Calendar.MINUTE, w % 60);
        wakeToday.set(Calendar.SECOND, 0);
        wakeToday.set(Calendar.MILLISECOND, 0);

        bedToday.set(Calendar.HOUR_OF_DAY, b / 60);
        bedToday.set(Calendar.MINUTE, b % 60);
        bedToday.set(Calendar.SECOND, 0);
        bedToday.set(Calendar.MILLISECOND, 0);

        // A deadline earlier than wake means the daytime window itself crosses midnight.
        if (!bedToday.after(wakeToday)) bedToday.add(Calendar.DATE, 1);

        long nowMs = now.getTimeInMillis();
        long wakeMs = wakeToday.getTimeInMillis();
        long bedMs = bedToday.getTimeInMillis();

        if (nowMs >= wakeMs && nowMs <= bedMs) {
            // Daytime countdown: wake -> deadline.
            return new long[]{wakeMs, bedMs};
        }

        if (nowMs > bedMs) {
            // Night countdown: deadline -> tomorrow's wake.
            Calendar nextWake = (Calendar) wakeToday.clone();
            nextWake.add(Calendar.DATE, 1);
            return new long[]{bedMs, nextWake.getTimeInMillis()};
        }

        // Before today's wake: night countdown began yesterday at the deadline.
        Calendar yesterdayBed = (Calendar) bedToday.clone();
        yesterdayBed.add(Calendar.DATE, -1);
        return new long[]{yesterdayBed.getTimeInMillis(), wakeMs};
    }
}
